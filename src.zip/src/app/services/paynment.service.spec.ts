import { TestBed } from '@angular/core/testing';

import { PaynmentService } from './paynment.service';

describe('PaynmentService', () => {
  let service: PaynmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PaynmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
