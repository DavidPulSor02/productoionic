import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PaynmentPage } from './paynment.page';

describe('PaynmentPage', () => {
  let component: PaynmentPage;
  let fixture: ComponentFixture<PaynmentPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PaynmentPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
