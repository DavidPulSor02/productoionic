import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PaynmentPageRoutingModule } from './paynment-routing.module';

import { PaynmentPage } from './paynment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PaynmentPageRoutingModule
  ],
  declarations: [PaynmentPage]
})
export class PaynmentPageModule {}
