import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paynment',
  templateUrl: './paynment.page.html',
  styleUrls: ['./paynment.page.scss'],
  standalone: false,
})
export class PaynmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
